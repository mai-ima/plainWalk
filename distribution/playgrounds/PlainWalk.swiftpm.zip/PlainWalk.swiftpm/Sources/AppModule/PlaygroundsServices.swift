import Foundation

// App playgrounds do not embed the HealthKit entitlement or a Live Activity extension.
final class HealthService {
    func authorize() async throws { throw NativeError.message("Playgrounds 版ではヘルスケアを利用できません。Xcode 版をお使いください。") }
    func steps() async throws -> Double? { try await authorize(); return nil }
    func workouts() async throws -> [[String: Any]] { try await authorize(); return [] }
    func route(id: String) async throws -> [[String: Any]] { try await authorize(); return [] }
}
@MainActor final class LiveActivityService {
    func update(_ session: NativeSession?) {}
}
